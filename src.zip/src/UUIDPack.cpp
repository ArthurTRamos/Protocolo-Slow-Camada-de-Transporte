#include "UUIDPack.h"
using namespace std;

UUIDPack::UUIDPack() {

}

void UUIDPack::setCustomA() {

}

void UUIDPack::setCustomB() {

}

void UUIDPack::setCustomC() {

}

void UUIDPack::setVar() {

}

void UUIDPack::setVer() {

}

bitset<128> UUIDPack::getUUID() {
    
}