#include <bits/stdc++.h>
#include "ConnectCentral.h"

using namespace std;

int main(void) {
    

    
    return 0;
}